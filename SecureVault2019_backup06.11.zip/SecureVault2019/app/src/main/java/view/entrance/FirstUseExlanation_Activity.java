package view.entrance;

public class FirstUseExlanation_Activity {
}
