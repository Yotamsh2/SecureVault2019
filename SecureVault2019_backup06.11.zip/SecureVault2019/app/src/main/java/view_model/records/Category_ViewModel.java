package view_model.records;


import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;

//Website
public class Category_ViewModel extends AndroidViewModel {


    public Category_ViewModel(@NonNull Application application) {
        super(application);
    }
}
